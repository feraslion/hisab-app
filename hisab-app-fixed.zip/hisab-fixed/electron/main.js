const { app, BrowserWindow } = require('electron');
const path = require('path');
const fs = require('fs');

const outDir = path.join(__dirname, '..', 'out');

function resolveHtmlFile(urlPath) {
  // Normalize: strip leading slash, handle root
  const rel = urlPath.replace(/^\//, '') || '';
  // Try exact html file first
  let candidate = path.join(outDir, rel);
  if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate;
  // Try appending index.html
  candidate = path.join(outDir, rel, 'index.html');
  if (fs.existsSync(candidate)) return candidate;
  // Try with .html extension
  candidate = path.join(outDir, rel + '.html');
  if (fs.existsSync(candidate)) return candidate;
  // Fallback to root
  return path.join(outDir, 'index.html');
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    title: 'حساب — نظام المحاسبة',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      // Allow Dexie/IndexedDB to work via file protocol
      webSecurity: false
    }
  });

  // Load the root page
  win.loadFile(path.join(outDir, 'index.html'));

  // Fix Next.js static export navigation under file:// protocol
  win.webContents.on('will-navigate', (event, url) => {
    event.preventDefault();
    try {
      const parsed = new URL(url);
      const filePath = resolveHtmlFile(parsed.pathname);
      win.loadFile(filePath);
    } catch {
      win.loadFile(path.join(outDir, 'index.html'));
    }
  });

  // Handle new windows (e.g. target="_blank") — open in same window
  win.webContents.setWindowOpenHandler(({ url }) => {
    try {
      const parsed = new URL(url);
      const filePath = resolveHtmlFile(parsed.pathname);
      win.loadFile(filePath);
    } catch {}
    return { action: 'deny' };
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
