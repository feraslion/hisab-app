# حساب — نظام المحاسبة

تطبيق محاسبة عربي يعمل بدون إنترنت (Offline-first)، مبني بـ Next.js + Dexie (IndexedDB) + Electron + Capacitor.

## المميزات

- ✅ يعمل بدون إنترنت بالكامل
- ✅ إدارة المنتجات (إضافة، تعديل، حذف، بحث)
- ✅ إدارة العملاء
- ✅ إنشاء فواتير البيع والشراء
- ✅ تتبع المخزون تلقائياً
- ✅ تقارير ومخططات المبيعات
- ✅ مزامنة اختيارية مع Supabase

## التشغيل محلياً

```bash
npm install
npm run dev
```

## البناء

### Windows (EXE)
```bash
npm run build:exe
```

### Android (APK)
```bash
npm run build:apk
```
> ملاحظة: لبناء APK يجب تثبيت Android Studio وإضافة مجلد android أولاً:
```bash
npm run cap:add
npm run build:apk
```

## متغيرات البيئة

انسخ `.env.local.example` إلى `.env.local` وعدّل القيم (اختياري للمزامنة السحابية):
```bash
cp .env.local.example .env.local
```

## البناء التلقائي (GitHub Actions)

المستودع مجهز بـ workflow يبني تلقائياً:
- **EXE** على كل push للـ main
- **APK** على كل push للـ main

الملفات تُرفع كـ Artifacts في GitHub Actions.
