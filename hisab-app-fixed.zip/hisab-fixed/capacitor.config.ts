import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.hisab.app',
  appName: 'حساب',
  webDir: 'out',
  android: {
    allowMixedContent: false,
    // Capacitor 6: use https scheme so web APIs (IndexedDB, etc.) work correctly
    webContentsDebuggingEnabled: false
  },
  server: {
    androidScheme: 'https'
  }
};

export default config;
