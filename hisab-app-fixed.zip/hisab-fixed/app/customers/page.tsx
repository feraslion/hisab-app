'use client';
import { useEffect, useState, useRef } from 'react';
import { listCustomers, createCustomer, updateCustomer, deleteCustomer } from '@/lib/services/customers';
import type { Customer } from '@/lib/db/local';

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [editId, setEditId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  const refresh = async () => setCustomers(await listCustomers());

  useEffect(() => { refresh(); }, []);

  // FIX: use onSubmit instead of action (React 18 client component)
  async function handleAdd(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const name = String(fd.get('name') || '').trim();
    if (!name) return;
    setLoading(true);
    try {
      await createCustomer({
        name,
        phone: String(fd.get('phone') || '') || null,
        email: null,
        address: null
      });
      formRef.current?.reset();
      await refresh();
    } finally {
      setLoading(false);
    }
  }

  async function handleUpdate(id: string) {
    if (!editName.trim()) return;
    await updateCustomer(id, { name: editName.trim(), phone: editPhone || null });
    setEditId(null);
    await refresh();
  }

  async function handleDelete(id: string, name: string) {
    if (!confirm(`هل تريد حذف العميل "${name}"؟`)) return;
    await deleteCustomer(id);
    await refresh();
  }

  return (
    <main>
      <h1 className="mb-6 text-2xl font-bold text-gray-800">👥 العملاء</h1>

      {/* Add form — FIX: onSubmit instead of action */}
      <form
        ref={formRef}
        onSubmit={handleAdd}
        className="mb-6 grid gap-3 rounded-xl border bg-white p-5 shadow-sm md:grid-cols-3"
      >
        <input
          name="name"
          placeholder="اسم العميل *"
          required
          className="rounded-lg border px-3 py-2 focus:border-blue-500 focus:outline-none"
        />
        <input
          name="phone"
          placeholder="رقم الهاتف"
          className="rounded-lg border px-3 py-2 focus:border-blue-500 focus:outline-none"
        />
        <button
          type="submit"
          disabled={loading}
          className="rounded-lg bg-blue-600 px-4 py-2 text-white font-medium hover:bg-blue-700 disabled:opacity-60 transition-colors"
        >
          {loading ? 'جارٍ الإضافة...' : '+ إضافة عميل'}
        </button>
      </form>

      {/* Customers list */}
      <div className="rounded-xl border bg-white shadow-sm overflow-hidden">
        {customers.length === 0 ? (
          <div className="p-8 text-center text-gray-400">لا يوجد عملاء بعد</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="text-right p-3 font-medium text-gray-600">#</th>
                <th className="text-right p-3 font-medium text-gray-600">الاسم</th>
                <th className="text-right p-3 font-medium text-gray-600">الهاتف</th>
                <th className="text-right p-3 font-medium text-gray-600">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {customers.map((c, idx) => (
                <tr key={c.id} className="border-b last:border-0 hover:bg-gray-50">
                  <td className="p-3 text-gray-400">{idx + 1}</td>
                  <td className="p-3">
                    {editId === c.id ? (
                      <input
                        value={editName}
                        onChange={e => setEditName(e.target.value)}
                        className="rounded border px-2 py-1 w-full focus:border-blue-500 focus:outline-none"
                      />
                    ) : (
                      <span className="font-medium">{c.name}</span>
                    )}
                  </td>
                  <td className="p-3 text-gray-600">
                    {editId === c.id ? (
                      <input
                        value={editPhone}
                        onChange={e => setEditPhone(e.target.value)}
                        className="rounded border px-2 py-1 w-full focus:border-blue-500 focus:outline-none"
                      />
                    ) : (
                      c.phone || '—'
                    )}
                  </td>
                  <td className="p-3">
                    {editId === c.id ? (
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleUpdate(c.id)}
                          className="rounded bg-green-600 px-3 py-1 text-white text-xs hover:bg-green-700"
                        >
                          حفظ
                        </button>
                        <button
                          onClick={() => setEditId(null)}
                          className="rounded bg-gray-300 px-3 py-1 text-xs hover:bg-gray-400"
                        >
                          إلغاء
                        </button>
                      </div>
                    ) : (
                      <div className="flex gap-2">
                        <button
                          onClick={() => { setEditId(c.id); setEditName(c.name); setEditPhone(c.phone || ''); }}
                          className="rounded bg-blue-100 text-blue-700 px-3 py-1 text-xs hover:bg-blue-200"
                        >
                          تعديل
                        </button>
                        <button
                          onClick={() => handleDelete(c.id, c.name)}
                          className="rounded bg-red-100 text-red-700 px-3 py-1 text-xs hover:bg-red-200"
                        >
                          حذف
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="mt-3 text-sm text-gray-400">
        إجمالي: {customers.length} عميل
      </div>
    </main>
  );
}
