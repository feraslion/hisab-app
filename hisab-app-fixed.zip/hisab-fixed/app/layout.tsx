import './globals.css';
import SyncProvider from '@/components/SyncProvider';
import Link from 'next/link';

export const metadata = {
  title: 'حساب — نظام المحاسبة',
  description: 'تطبيق محاسبة يعمل بدون إنترنت'
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl">
      <body>
        <SyncProvider>
          <nav className="flex flex-wrap items-center gap-1 bg-blue-700 px-4 py-2 shadow-md">
            <Link href="/" className="font-bold text-white px-3 py-1 rounded hover:bg-blue-600 transition-colors">
              🏠 الرئيسية
            </Link>
            <Link href="/products" className="text-blue-100 px-3 py-1 rounded hover:bg-blue-600 transition-colors">
              📦 المنتجات
            </Link>
            <Link href="/customers" className="text-blue-100 px-3 py-1 rounded hover:bg-blue-600 transition-colors">
              👥 العملاء
            </Link>
            <Link href="/invoices/create" className="text-blue-100 px-3 py-1 rounded hover:bg-blue-600 transition-colors">
              ➕ فاتورة جديدة
            </Link>
            <Link href="/invoices" className="text-blue-100 px-3 py-1 rounded hover:bg-blue-600 transition-colors">
              📄 الفواتير
            </Link>
            <Link href="/reports" className="text-blue-100 px-3 py-1 rounded hover:bg-blue-600 transition-colors">
              📊 التقارير
            </Link>
          </nav>
          <div className="mx-auto max-w-6xl p-4">{children}</div>
        </SyncProvider>
      </body>
    </html>
  );
}
