'use client';
import { useEffect, useState } from 'react';
import { db } from '@/lib/db/local';
import Link from 'next/link';

interface Stats {
  products: number;
  customers: number;
  invoices: number;
  totalSales: number;
  lowStock: number;
}

export default function Home() {
  const [stats, setStats] = useState<Stats>({
    products: 0, customers: 0, invoices: 0, totalSales: 0, lowStock: 0
  });

  useEffect(() => {
    (async () => {
      const [products, customers, invoices] = await Promise.all([
        db.products.toArray(),
        db.customers.count(),
        db.invoices.toArray()
      ]);

      const activeProducts = products.filter(p => !p.deleted);
      const lowStock = activeProducts.filter(p => p.stock <= p.minstock).length;
      const salesInvoices = invoices.filter(i => !i.deleted && i.type === 'sale');
      const totalSales = salesInvoices.reduce((s, i) => s + i.total, 0);

      setStats({
        products: activeProducts.length,
        customers,
        invoices: invoices.filter(i => !i.deleted).length,
        totalSales,
        lowStock
      });
    })();
  }, []);

  return (
    <main>
      <h1 className="mb-6 text-3xl font-bold text-gray-800">لوحة التحكم</h1>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
        <StatCard title="المنتجات" value={stats.products} icon="📦" color="blue" href="/products" />
        <StatCard title="العملاء" value={stats.customers} icon="👥" color="green" href="/customers" />
        <StatCard title="الفواتير" value={stats.invoices} icon="📄" color="purple" href="/invoices" />
        <StatCard
          title="إجمالي المبيعات"
          value={stats.totalSales.toFixed(2)}
          icon="💰"
          color="yellow"
          href="/reports"
          suffix=" ر.س"
        />
      </div>

      {stats.lowStock > 0 && (
        <div className="mb-6 rounded-lg border border-red-200 bg-red-50 p-4 flex items-center gap-3">
          <span className="text-2xl">⚠️</span>
          <div>
            <div className="font-bold text-red-700">تنبيه: مخزون منخفض</div>
            <div className="text-sm text-red-600">
              {stats.lowStock} منتج وصل للحد الأدنى.{' '}
              <Link href="/products" className="underline font-medium">عرض المنتجات</Link>
            </div>
          </div>
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-3">
        <QuickAction href="/products" icon="📦" label="إدارة المنتجات" desc="إضافة وتعديل وحذف المنتجات" />
        <QuickAction href="/customers" icon="👥" label="إدارة العملاء" desc="إضافة وتعديل العملاء" />
        <QuickAction href="/invoices/create" icon="➕" label="فاتورة جديدة" desc="إنشاء فاتورة بيع أو شراء" />
      </div>
    </main>
  );
}

function StatCard({
  title, value, icon, color, href, suffix = ''
}: {
  title: string; value: number | string; icon: string;
  color: 'blue' | 'green' | 'purple' | 'yellow';
  href: string; suffix?: string;
}) {
  const colors = {
    blue: 'bg-blue-50 border-blue-200 text-blue-700',
    green: 'bg-green-50 border-green-200 text-green-700',
    purple: 'bg-purple-50 border-purple-200 text-purple-700',
    yellow: 'bg-yellow-50 border-yellow-200 text-yellow-700',
  };
  return (
    <Link href={href} className={`rounded-xl border p-5 shadow-sm hover:shadow-md transition-shadow ${colors[color]}`}>
      <div className="text-2xl mb-2">{icon}</div>
      <div className="text-sm font-medium opacity-75">{title}</div>
      <div className="text-2xl font-bold mt-1">{value}{suffix}</div>
    </Link>
  );
}

function QuickAction({ href, icon, label, desc }: { href: string; icon: string; label: string; desc: string }) {
  return (
    <Link href={href} className="block rounded-xl border bg-white p-5 shadow-sm hover:shadow-md transition-shadow hover:border-blue-300">
      <div className="text-3xl mb-3">{icon}</div>
      <div className="font-bold text-gray-800">{label}</div>
      <div className="text-sm text-gray-500 mt-1">{desc}</div>
    </Link>
  );
}
