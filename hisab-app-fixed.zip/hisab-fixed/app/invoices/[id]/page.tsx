'use client';
import { useEffect, useState } from 'react';
import { getInvoiceWithItems } from '@/lib/services/invoices';
import { db } from '@/lib/db/local';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import type { Invoice, InvoiceItem, Product, Customer } from '@/lib/db/local';

interface InvoiceDetail {
  invoice: Invoice;
  items: (InvoiceItem & { productName: string })[];
  customerName: string;
}

export default function InvoiceDetailPage() {
  const params = useParams();
  const id = params?.id as string;
  const [detail, setDetail] = useState<InvoiceDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    (async () => {
      try {
        const result = await getInvoiceWithItems(id);
        setDetail(result);
      } finally {
        setLoading(false);
      }
    })();
  }, [id]);

  if (loading) return <main className="p-8 text-center text-gray-400">جارٍ التحميل...</main>;
  if (!detail) return <main className="p-8 text-center text-gray-400">الفاتورة غير موجودة</main>;

  const { invoice, items, customerName } = detail;

  const handlePrint = () => window.print();

  return (
    <main>
      <div className="mb-6 flex items-center justify-between flex-wrap gap-3 no-print">
        <Link href="/invoices" className="text-blue-600 hover:underline text-sm">← العودة للفواتير</Link>
        <button onClick={handlePrint} className="rounded-lg bg-gray-700 px-4 py-2 text-white text-sm hover:bg-gray-800">
          🖨️ طباعة
        </button>
      </div>

      <div className="rounded-xl border bg-white p-6 shadow-sm">
        <div className="mb-6 flex items-start justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-1">
              {invoice.type === 'sale' ? 'فاتورة بيع' : 'فاتورة شراء'}
            </h1>
            <div className="text-sm text-gray-500">رقم: {invoice.id.slice(0, 8).toUpperCase()}</div>
          </div>
          <div className="text-left text-sm text-gray-600">
            <div><strong>التاريخ:</strong> {new Date(invoice.createdat).toLocaleString('ar-SA')}</div>
            <div><strong>العميل:</strong> {customerName}</div>
            <div>
              <strong>الحالة:</strong>{' '}
              <span className={`rounded-full px-2 py-0.5 text-xs ${
                invoice.syncstatus === 'synced' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
              }`}>
                {invoice.syncstatus === 'synced' ? 'مزامن' : 'معلق'}
              </span>
            </div>
          </div>
        </div>

        <table className="w-full text-sm mb-6">
          <thead className="bg-gray-50 border-y">
            <tr>
              <th className="text-right p-3 font-medium text-gray-600">#</th>
              <th className="text-right p-3 font-medium text-gray-600">المنتج</th>
              <th className="text-right p-3 font-medium text-gray-600">الكمية</th>
              <th className="text-right p-3 font-medium text-gray-600">سعر الوحدة</th>
              <th className="text-right p-3 font-medium text-gray-600">الإجمالي</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, idx) => (
              <tr key={item.id} className="border-b last:border-0">
                <td className="p-3 text-gray-400">{idx + 1}</td>
                <td className="p-3 font-medium">{item.productName}</td>
                <td className="p-3">{item.quantity}</td>
                <td className="p-3">{item.unitprice.toFixed(2)} ر.س</td>
                <td className="p-3 font-bold">{item.total.toFixed(2)} ر.س</td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-gray-50 border-t-2">
            <tr>
              <td colSpan={4} className="p-3 text-right font-bold text-gray-700">الإجمالي</td>
              <td className="p-3 font-bold text-lg text-green-700">{invoice.total.toFixed(2)} ر.س</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </main>
  );
}
