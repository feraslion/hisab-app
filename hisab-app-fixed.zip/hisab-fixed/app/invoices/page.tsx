'use client';
import { useEffect, useState } from 'react';
import { listInvoices } from '@/lib/services/invoices';
import { listCustomers } from '@/lib/services/customers';
import type { Invoice, Customer } from '@/lib/db/local';
import Link from 'next/link';

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [customerMap, setCustomerMap] = useState<Record<string, string>>({});
  const [filter, setFilter] = useState<'all' | 'sale' | 'purchase'>('all');

  useEffect(() => {
    listInvoices().then(setInvoices);
    listCustomers().then(cs => {
      const map: Record<string, string> = {};
      cs.forEach(c => (map[c.id] = c.name));
      setCustomerMap(map);
    });
  }, []);

  const filtered = invoices.filter(i => filter === 'all' || i.type === filter);
  const totalSales = filtered.filter(i => i.type === 'sale').reduce((s, i) => s + i.total, 0);
  const totalPurchases = filtered.filter(i => i.type === 'purchase').reduce((s, i) => s + i.total, 0);

  return (
    <main>
      <div className="mb-6 flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-bold text-gray-800">📄 الفواتير</h1>
        <Link href="/invoices/create" className="rounded-lg bg-blue-600 px-4 py-2 text-white text-sm font-medium hover:bg-blue-700">
          + فاتورة جديدة
        </Link>
      </div>

      {/* Summary */}
      <div className="grid gap-4 md:grid-cols-2 mb-6">
        <div className="rounded-xl border bg-green-50 p-4">
          <div className="text-sm text-green-600 font-medium">إجمالي المبيعات</div>
          <div className="text-2xl font-bold text-green-700">{totalSales.toFixed(2)} ر.س</div>
        </div>
        <div className="rounded-xl border bg-blue-50 p-4">
          <div className="text-sm text-blue-600 font-medium">إجمالي المشتريات</div>
          <div className="text-2xl font-bold text-blue-700">{totalPurchases.toFixed(2)} ر.س</div>
        </div>
      </div>

      {/* Filter */}
      <div className="mb-4 flex gap-2">
        {(['all', 'sale', 'purchase'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-lg px-4 py-1.5 text-sm font-medium transition-colors ${filter === f ? 'bg-blue-600 text-white' : 'bg-white border text-gray-600 hover:bg-gray-50'}`}
          >
            {f === 'all' ? 'الكل' : f === 'sale' ? 'المبيعات' : 'المشتريات'}
          </button>
        ))}
      </div>

      <div className="rounded-xl border bg-white shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="text-right p-3 font-medium text-gray-600">التاريخ</th>
              <th className="text-right p-3 font-medium text-gray-600">العميل</th>
              <th className="text-right p-3 font-medium text-gray-600">النوع</th>
              <th className="text-right p-3 font-medium text-gray-600">الإجمالي</th>
              <th className="text-right p-3 font-medium text-gray-600">التزامن</th>
              <th className="text-right p-3 font-medium text-gray-600">التفاصيل</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={6} className="p-8 text-center text-gray-400">لا توجد فواتير</td></tr>
            )}
            {filtered.map(i => (
              <tr key={i.id} className="border-b last:border-0 hover:bg-gray-50">
                <td className="p-3 text-gray-600">{new Date(i.createdat).toLocaleString('ar-SA')}</td>
                <td className="p-3 font-medium">{i.customerid ? (customerMap[i.customerid] || '—') : 'نقدي'}</td>
                <td className="p-3">
                  {i.type === 'sale'
                    ? <span className="rounded-full bg-green-100 text-green-700 px-2 py-0.5 text-xs font-medium">بيع</span>
                    : <span className="rounded-full bg-blue-100 text-blue-700 px-2 py-0.5 text-xs font-medium">شراء</span>}
                </td>
                <td className="p-3 font-bold">{i.total.toFixed(2)} ر.س</td>
                <td className="p-3">
                  <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                    i.syncstatus === 'synced' ? 'bg-green-100 text-green-700' :
                    i.syncstatus === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {i.syncstatus === 'synced' ? 'مزامن' : i.syncstatus === 'pending' ? 'معلق' : 'خطأ'}
                  </span>
                </td>
                <td className="p-3">
                  <Link href={`/invoices/${i.id}`} className="text-blue-600 hover:underline text-xs">
                    عرض
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
