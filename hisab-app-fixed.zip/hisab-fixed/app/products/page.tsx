'use client';
import { useEffect, useState, useRef } from 'react';
import { listProducts, createProduct, updateProduct, deleteProduct } from '@/lib/services/products';
import type { Product } from '@/lib/db/local';

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [editId, setEditId] = useState<string | null>(null);
  const [editData, setEditData] = useState({ name: '', price: '', stock: '', minstock: '' });
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const formRef = useRef<HTMLFormElement>(null);

  const refresh = async () => setProducts(await listProducts());
  useEffect(() => { refresh(); }, []);

  // FIX: use onSubmit instead of action (React 18 client component)
  async function handleAdd(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setLoading(true);
    try {
      await createProduct({
        name: String(fd.get('name')).trim(),
        barcode: String(fd.get('barcode')).trim(),
        price: Number(fd.get('price') || 0),
        stock: Number(fd.get('stock') || 0),
        minstock: Number(fd.get('minstock') || 0)
      });
      formRef.current?.reset();
      await refresh();
    } catch (e: any) {
      alert(e.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleUpdate(id: string) {
    await updateProduct(id, {
      name: editData.name.trim(),
      price: Number(editData.price),
      stock: Number(editData.stock),
      minstock: Number(editData.minstock)
    });
    setEditId(null);
    await refresh();
  }

  async function handleDelete(id: string, name: string) {
    if (!confirm(`هل تريد حذف "${name}"؟`)) return;
    await deleteProduct(id);
    await refresh();
  }

  const filtered = products.filter(p =>
    p.name.includes(search) || p.barcode.includes(search)
  );

  return (
    <main>
      <h1 className="mb-6 text-2xl font-bold text-gray-800">📦 المنتجات</h1>

      {/* Add form — FIX: onSubmit */}
      <form
        ref={formRef}
        onSubmit={handleAdd}
        className="mb-6 rounded-xl border bg-white p-5 shadow-sm"
      >
        <h2 className="mb-3 font-semibold text-gray-700">إضافة منتج جديد</h2>
        <div className="grid gap-3 md:grid-cols-6">
          <input name="name" placeholder="الاسم *" required className="rounded-lg border px-3 py-2 focus:border-blue-500 focus:outline-none" />
          <input name="barcode" placeholder="الباركود *" required className="rounded-lg border px-3 py-2 focus:border-blue-500 focus:outline-none" />
          <input name="price" type="number" step="0.01" min="0" placeholder="السعر" className="rounded-lg border px-3 py-2 focus:border-blue-500 focus:outline-none" />
          <input name="stock" type="number" min="0" placeholder="المخزون" className="rounded-lg border px-3 py-2 focus:border-blue-500 focus:outline-none" />
          <input name="minstock" type="number" min="0" placeholder="الحد الأدنى" className="rounded-lg border px-3 py-2 focus:border-blue-500 focus:outline-none" />
          <button
            type="submit"
            disabled={loading}
            className="rounded-lg bg-blue-600 px-4 py-2 text-white font-medium hover:bg-blue-700 disabled:opacity-60 transition-colors"
          >
            {loading ? '...' : '+ إضافة'}
          </button>
        </div>
      </form>

      {/* Search */}
      <div className="mb-4 flex items-center gap-3">
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="🔍 بحث بالاسم أو الباركود..."
          className="rounded-lg border px-3 py-2 w-64 focus:border-blue-500 focus:outline-none"
        />
        <span className="text-sm text-gray-500">{filtered.length} منتج</span>
        {products.filter(p => p.stock <= p.minstock).length > 0 && (
          <span className="text-sm text-red-600 font-medium">
            ⚠️ {products.filter(p => p.stock <= p.minstock).length} منتج بمخزون منخفض
          </span>
        )}
      </div>

      {/* Table */}
      <div className="rounded-xl border bg-white shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="text-right p-3 font-medium text-gray-600">الاسم</th>
              <th className="text-right p-3 font-medium text-gray-600">الباركود</th>
              <th className="text-right p-3 font-medium text-gray-600">السعر</th>
              <th className="text-right p-3 font-medium text-gray-600">المخزون</th>
              <th className="text-right p-3 font-medium text-gray-600">الحالة</th>
              <th className="text-right p-3 font-medium text-gray-600">الإجراءات</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={6} className="p-8 text-center text-gray-400">لا توجد منتجات</td></tr>
            )}
            {filtered.map(p => (
              <tr key={p.id} className={`border-b last:border-0 hover:bg-gray-50 ${p.stock <= p.minstock ? 'bg-red-50' : ''}`}>
                <td className="p-3 font-medium">
                  {editId === p.id ? (
                    <input value={editData.name} onChange={e => setEditData(d => ({ ...d, name: e.target.value }))}
                      className="rounded border px-2 py-1 w-full focus:border-blue-500 focus:outline-none" />
                  ) : p.name}
                </td>
                <td className="p-3 text-gray-500 font-mono text-xs">{p.barcode}</td>
                <td className="p-3">
                  {editId === p.id ? (
                    <input type="number" value={editData.price} onChange={e => setEditData(d => ({ ...d, price: e.target.value }))}
                      className="rounded border px-2 py-1 w-20 focus:border-blue-500 focus:outline-none" />
                  ) : <span>{p.price.toFixed(2)} ر.س</span>}
                </td>
                <td className="p-3">
                  {editId === p.id ? (
                    <div className="flex gap-1">
                      <input type="number" value={editData.stock} onChange={e => setEditData(d => ({ ...d, stock: e.target.value }))}
                        className="rounded border px-2 py-1 w-16 focus:border-blue-500 focus:outline-none" placeholder="المخزون" />
                      <input type="number" value={editData.minstock} onChange={e => setEditData(d => ({ ...d, minstock: e.target.value }))}
                        className="rounded border px-2 py-1 w-16 focus:border-blue-500 focus:outline-none" placeholder="الحد" />
                    </div>
                  ) : (
                    <span>{p.stock} / {p.minstock}</span>
                  )}
                </td>
                <td className="p-3">
                  {p.stock <= p.minstock
                    ? <span className="rounded-full bg-red-100 text-red-700 px-2 py-0.5 text-xs font-medium">منخفض</span>
                    : <span className="rounded-full bg-green-100 text-green-700 px-2 py-0.5 text-xs font-medium">جيد</span>}
                </td>
                <td className="p-3">
                  {editId === p.id ? (
                    <div className="flex gap-2">
                      <button onClick={() => handleUpdate(p.id)} className="rounded bg-green-600 px-3 py-1 text-white text-xs hover:bg-green-700">حفظ</button>
                      <button onClick={() => setEditId(null)} className="rounded bg-gray-300 px-3 py-1 text-xs hover:bg-gray-400">إلغاء</button>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <button
                        onClick={() => { setEditId(p.id); setEditData({ name: p.name, price: String(p.price), stock: String(p.stock), minstock: String(p.minstock) }); }}
                        className="rounded bg-blue-100 text-blue-700 px-3 py-1 text-xs hover:bg-blue-200"
                      >تعديل</button>
                      <button onClick={() => handleDelete(p.id, p.name)} className="rounded bg-red-100 text-red-700 px-3 py-1 text-xs hover:bg-red-200">حذف</button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
