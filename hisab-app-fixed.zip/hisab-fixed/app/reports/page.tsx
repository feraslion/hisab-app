'use client';
import { useEffect, useState } from 'react';
import { db } from '@/lib/db/local';

interface DaySales { date: string; total: number; count: number; }
interface TopProduct { name: string; qty: number; revenue: number; }

export default function ReportsPage() {
  const [daySales, setDaySales] = useState<DaySales[]>([]);
  const [topProducts, setTopProducts] = useState<TopProduct[]>([]);
  const [totals, setTotals] = useState({ sales: 0, purchases: 0, profit: 0, invoices: 0 });

  useEffect(() => {
    (async () => {
      const [invoices, items, products] = await Promise.all([
        db.invoices.toArray(),
        db.invoiceitems.toArray(),
        db.products.toArray()
      ]);

      const activeInvoices = invoices.filter(i => !i.deleted);
      const sales = activeInvoices.filter(i => i.type === 'sale');
      const purchases = activeInvoices.filter(i => i.type === 'purchase');
      const totalSales = sales.reduce((s, i) => s + i.total, 0);
      const totalPurchases = purchases.reduce((s, i) => s + i.total, 0);

      setTotals({
        sales: totalSales,
        purchases: totalPurchases,
        profit: totalSales - totalPurchases,
        invoices: activeInvoices.length
      });

      // Daily sales (last 7 days)
      const last7 = Array.from({ length: 7 }, (_, i) => {
        const d = new Date();
        d.setDate(d.getDate() - (6 - i));
        return d.toISOString().slice(0, 10);
      });

      const dayMap: Record<string, DaySales> = {};
      last7.forEach(d => (dayMap[d] = { date: d, total: 0, count: 0 }));
      sales.forEach(inv => {
        const day = inv.createdat.slice(0, 10);
        if (dayMap[day]) {
          dayMap[day].total += inv.total;
          dayMap[day].count++;
        }
      });
      setDaySales(last7.map(d => dayMap[d]));

      // Top products by revenue (from sale invoices)
      const saleInvoiceIds = new Set(sales.map(i => i.id));
      const saleItems = items.filter(it => saleInvoiceIds.has(it.invoiceid));
      const prodMap: Record<string, { qty: number; revenue: number }> = {};
      saleItems.forEach(it => {
        if (!prodMap[it.productid]) prodMap[it.productid] = { qty: 0, revenue: 0 };
        prodMap[it.productid].qty += it.quantity;
        prodMap[it.productid].revenue += it.total;
      });
      const productNameMap: Record<string, string> = {};
      products.forEach(p => (productNameMap[p.id] = p.name));

      const top = Object.entries(prodMap)
        .map(([id, d]) => ({ name: productNameMap[id] || id, ...d }))
        .sort((a, b) => b.revenue - a.revenue)
        .slice(0, 10);
      setTopProducts(top);
    })();
  }, []);

  const maxDay = Math.max(...daySales.map(d => d.total), 1);

  return (
    <main>
      <h1 className="mb-6 text-2xl font-bold text-gray-800">📊 التقارير</h1>

      {/* KPIs */}
      <div className="grid gap-4 md:grid-cols-4 mb-8">
        <KPICard label="إجمالي المبيعات" value={`${totals.sales.toFixed(2)} ر.س`} icon="💰" color="green" />
        <KPICard label="إجمالي المشتريات" value={`${totals.purchases.toFixed(2)} ر.س`} icon="🛒" color="blue" />
        <KPICard
          label="صافي الربح"
          value={`${totals.profit.toFixed(2)} ر.س`}
          icon="📈"
          color={totals.profit >= 0 ? 'green' : 'red'}
        />
        <KPICard label="عدد الفواتير" value={String(totals.invoices)} icon="📄" color="purple" />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Daily Sales Chart */}
        <div className="rounded-xl border bg-white p-5 shadow-sm">
          <h2 className="mb-4 font-semibold text-gray-700">المبيعات - آخر 7 أيام</h2>
          <div className="flex items-end gap-2 h-40">
            {daySales.map(d => (
              <div key={d.date} className="flex flex-col items-center flex-1 gap-1">
                <div className="text-xs text-gray-500 font-medium">
                  {d.total > 0 ? d.total.toFixed(0) : ''}
                </div>
                <div
                  className="w-full bg-blue-500 rounded-t transition-all hover:bg-blue-600"
                  style={{ height: `${(d.total / maxDay) * 120 + (d.total > 0 ? 4 : 0)}px`, minHeight: d.total > 0 ? '4px' : '2px' }}
                  title={`${d.total.toFixed(2)} ر.س`}
                />
                <div className="text-xs text-gray-400 rotate-0">
                  {new Date(d.date).toLocaleDateString('ar-SA', { weekday: 'short' })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Products */}
        <div className="rounded-xl border bg-white p-5 shadow-sm">
          <h2 className="mb-4 font-semibold text-gray-700">أفضل المنتجات مبيعاً</h2>
          {topProducts.length === 0 ? (
            <div className="text-gray-400 text-sm text-center py-8">لا توجد بيانات بعد</div>
          ) : (
            <div className="space-y-3">
              {topProducts.map((p, idx) => (
                <div key={p.name} className="flex items-center gap-3">
                  <span className="text-gray-400 text-sm w-5">{idx + 1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{p.name}</div>
                    <div className="text-xs text-gray-400">{p.qty} وحدة</div>
                  </div>
                  <div className="text-sm font-bold text-green-700">{p.revenue.toFixed(0)} ر.س</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}

function KPICard({ label, value, icon, color }: { label: string; value: string; icon: string; color: string }) {
  const colors: Record<string, string> = {
    green: 'bg-green-50 border-green-200',
    blue: 'bg-blue-50 border-blue-200',
    purple: 'bg-purple-50 border-purple-200',
    red: 'bg-red-50 border-red-200',
  };
  return (
    <div className={`rounded-xl border p-5 shadow-sm ${colors[color] || 'bg-gray-50'}`}>
      <div className="text-2xl mb-2">{icon}</div>
      <div className="text-xs text-gray-500 font-medium mb-1">{label}</div>
      <div className="text-xl font-bold text-gray-800">{value}</div>
    </div>
  );
}
